const express = require('express');
const path = require('path');
const app = express();

// Middleware for parsing request bodies
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files (HTML, CSS, etc.)
app.use(express.static('public'));

// Set views directory for rendering HTML pages
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Home route
app.get('/', (req, res) => {
  res.render('index', { title: 'St John\'s Catholic Secondary School' });
});

// Teachers login route
app.get('/login', (req, res) => {
  res.render('login', { title: 'Teacher Login' });
});

// Route to upload results (this is a placeholder for functionality)
app.post('/upload-results', (req, res) => {
  // Simulate file upload functionality
  const results = req.body.results;
  res.send(`Results uploaded: ${results}`);
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
